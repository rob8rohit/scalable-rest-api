# Frontend - Scalable REST API Demo

This is a minimal React demo. To run:
1. npm install
2. npm start

The UI expects backend at http://localhost:4000
