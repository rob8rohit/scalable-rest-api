import React, { useState } from 'react';
import Register from './Register';
import Login from './Login';
import Dashboard from './Dashboard';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('token') || null);
  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h2>Scalable REST API - Demo UI</h2>
      {!token ? (
        <>
          <Login onLogin={(t)=>{ setToken(t); localStorage.setItem('token', t); }} />
          <hr />
          <Register />
        </>
      ) : (
        <Dashboard token={token} onLogout={() => { localStorage.removeItem('token'); setToken(null); }} />
      )}
    </div>
  );
}
