import React, { useEffect, useState } from 'react';

export default function Dashboard({ token, onLogout }) {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState({ title:'', description:''});
  const [msg, setMsg] = useState(null);

  async function load() {
    try {
      const res = await fetch('http://localhost:4000/api/v1/tasks', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      setTasks(data);
    } catch (err) { setMsg(err.message); }
  }

  useEffect(()=>{ load(); }, []);

  async function create(e) {
    e.preventDefault();
    try {
      const res = await fetch('http://localhost:4000/api/v1/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Error');
      setForm({title:'',description:''});
      load();
    } catch (err) { setMsg(err.message); }
  }

  return (
    <div>
      <button onClick={onLogout}>Logout</button>
      <h3>Dashboard - Tasks</h3>
      <form onSubmit={create}>
        <input placeholder="Title" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} required /><br/>
        <textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}></textarea><br/>
        <button type="submit">Create Task</button>
      </form>

      {msg && <p>{msg}</p>}

      <ul>
        {tasks.map(t=>(
          <li key={t.id}><strong>{t.title}</strong> — {t.description} ({t.status})</li>
        ))}
      </ul>
    </div>
  );
}
