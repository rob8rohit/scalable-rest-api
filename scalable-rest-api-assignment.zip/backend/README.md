# Backend - Scalable REST API Assignment

## Run locally (quick)
1. Install dependencies:
   npm install

2. Start server:
   npm run dev

By default the project uses SQLite (database.sqlite in working dir) for quick demo.
Set DATABASE_URL in .env to use Postgres/MySQL if desired.
