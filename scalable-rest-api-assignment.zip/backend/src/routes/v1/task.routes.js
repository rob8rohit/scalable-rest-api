const express = require('express');
const router = express.Router();
const taskCtrl = require('../../controllers/task.controller');
const auth = require('../../middlewares/auth.middleware');

router.post('/', auth, taskCtrl.create);
router.get('/', auth, taskCtrl.list);
router.get('/:id', auth, taskCtrl.get);
router.put('/:id', auth, taskCtrl.update);
router.delete('/:id', auth, taskCtrl.remove);

module.exports = router;
