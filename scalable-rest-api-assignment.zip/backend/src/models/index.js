const { Sequelize, DataTypes } = require('sequelize');
const DATABASE_URL = process.env.DATABASE_URL || 'sqlite::memory:';

const sequelize = new Sequelize(DATABASE_URL, {
  logging: false,
  dialect: 'sqlite'
});

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.User = require('./user.model')(sequelize, DataTypes);
db.Task = require('./task.model')(sequelize, DataTypes);

db.User.hasMany(db.Task, { foreignKey: 'ownerId', as: 'tasks' });
db.Task.belongsTo(db.User, { foreignKey: 'ownerId', as: 'owner' });

module.exports = db;
