const { Task } = require('../models');

exports.create = async (req, res, next) => {
  try {
    const { title, description } = req.body;
    const task = await Task.create({ title, description, ownerId: req.user.id });
    res.status(201).json(task);
  } catch (err) { next(err); }
};

exports.list = async (req, res, next) => {
  try {
    let tasks;
    if (req.user.role === 'admin') {
      tasks = await Task.findAll();
    } else {
      tasks = await Task.findAll({ where: { ownerId: req.user.id }});
    }
    res.json(tasks);
  } catch (err) { next(err); }
};

exports.get = async (req, res, next) => {
  try {
    const t = await Task.findByPk(req.params.id);
    if (!t) return res.status(404).json({ message: 'Not found' });
    if (req.user.role !== 'admin' && t.ownerId !== req.user.id) return res.status(403).json({ message: 'Forbidden' });
    res.json(t);
  } catch (err) { next(err); }
};

exports.update = async (req, res, next) => {
  try {
    const t = await Task.findByPk(req.params.id);
    if (!t) return res.status(404).json({ message: 'Not found' });
    if (req.user.role !== 'admin' && t.ownerId !== req.user.id) return res.status(403).json({ message: 'Forbidden' });
    await t.update(req.body);
    res.json(t);
  } catch (err) { next(err); }
};

exports.remove = async (req, res, next) => {
  try {
    const t = await Task.findByPk(req.params.id);
    if (!t) return res.status(404).json({ message: 'Not found' });
    if (req.user.role !== 'admin' && t.ownerId !== req.user.id) return res.status(403).json({ message: 'Forbidden' });
    await t.destroy();
    res.json({ success: true });
  } catch (err) { next(err); }
};
