const { verify } = require('../utils/jwt');
const { User } = require('../models');

async function auth(req, res, next) {
  try {
    const header = req.headers.authorization;
    if (!header) return res.status(401).json({ message: 'Missing token' });
    const token = header.split(' ')[1];
    const payload = verify(token);
    const user = await User.findByPk(payload.id, { attributes: { exclude: ['password_hash'] }});
    if (!user) return res.status(401).json({ message: 'Invalid token' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Unauthorized', details: err.message });
  }
}

module.exports = auth;
