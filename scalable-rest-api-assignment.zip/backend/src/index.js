require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const db = require('./models');
const v1Auth = require('./routes/v1/auth.routes');
const v1Tasks = require('./routes/v1/task.routes');
const errorHandler = require('./middlewares/error.middleware');
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./docs/swagger');

const app = express();
app.use(bodyParser.json());

app.use('/api/v1/auth', v1Auth);
app.use('/api/v1/tasks', v1Tasks);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.use(errorHandler);

const PORT = process.env.PORT || 4000;
db.sequelize.sync().then(() => {
  app.listen(PORT, () => console.log(`Server running on ${PORT}`));
});
