# Scalable REST API Assignment - Sample Project

This archive contains:
- backend/  : Node.js + Express + Sequelize (SQLite default)
- frontend/ : Minimal React UI demonstrating auth & tasks

See backend/README.md and frontend/README.md for quick run instructions.

Notes:
- For a production DB swap DATABASE_URL in backend/.env.example to a Postgres/MySQL connection string.
- This is a compact demo intended to be extended for the assignment.
